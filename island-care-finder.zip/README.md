# Island Care Finder

Helps families find long-term care, assisted living, retirement residences and home-care companies near a family member on Vancouver Island.

**Live site:** https://rishabhjha1.github.io/homecare/

## How it works
- `index.html` is the whole site. It reads `data/Vancouver-Island-Care-Directory.xlsx` in the browser (SheetJS), so there is no server or build step.
- The spreadsheet has two sheets: **Facilities** and **In-Home Care**. Headers must stay the same.
- Map pins start at town centres, then move to street addresses using the free BC Address Geocoder. Results are cached in each visitor's browser.

## Updating the listings
1. Edit the spreadsheet (add, remove or change rows; keep the column headers).
2. Replace `data/Vancouver-Island-Care-Directory.xlsx` in this repo and commit.
3. The site updates within a minute or two.

Optional: add `Latitude` and `Longitude` columns for exact pins. Use the "Download the data with map coordinates" link in the site footer to get a copy with coordinates already filled in.

## Publishing on GitHub Pages
Settings → Pages → Deploy from a branch → `main` / root.
